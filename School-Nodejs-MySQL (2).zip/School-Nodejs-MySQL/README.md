# College-Attendance-System
Attendance Management System Node Js project

Requirements:
Node Js
My SQL

How to Use:
Download zip project and extract.
Install Node 
npm init
import sql file to mysql

User Name and Password 
admin
admin
